import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-list-todos',
  templateUrl: './list-todos.component.html',
  styleUrls: ['./list-todos.component.css']
})
export class ListTodosComponent implements OnInit {

  // todo = {
  //   'id' : 1,
  //   'discription' : 'Learning Angular'
  // }

  // todos = [
  //   {'id' : 1, discription : 'visit CTS Learning app'},
  //   {'id' : 2, discription : 'Become expert in Angular'},
  //   {'id' : 3, discription : 'Start development'}
  // ]
  
  todos = [
    new Todo(1, 'visit CTS Learning app', new Date(), false),
    new Todo(2, 'Become expert in Angular', new Date(), false),
    new Todo(3, 'Start development', new Date(), false),
    new Todo(4, 'visit Inda', new Date(), false)
  ]

  constructor() { }

  ngOnInit() {
  }

}

export class Todo{
  constructor(
    public id : number,
    public discription : String,
    public completed : Date,
    public status : boolean
  ){}
}
